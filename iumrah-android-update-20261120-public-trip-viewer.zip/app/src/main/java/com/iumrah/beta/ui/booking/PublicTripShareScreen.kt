package com.iumrah.beta.ui.booking

import android.content.Intent
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebSettings
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView

/**
 * The public trip is the very same read-only HTTPS document on iOS, web and
 * Android. Never attach booking tokens, account cookies or a JS bridge here.
 * Booking management is a separate owner-authorized route.
 */
@Composable
fun PublicTripShareScreen(token: String) {
    val context = LocalContext.current
    val safeToken = remember(token) { token.takeIf { it.matches(Regex("^[A-Za-z0-9_-]{43}$")) } }
    val webView = remember(context, safeToken) {
        WebView(context).apply {
            settings.javaScriptEnabled = true // Needed by the public Next.js page
            // Next.js public page uses client-side locale preferences. No owner secrets are exposed.
            settings.domStorageEnabled = true
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, false)
            settings.cacheMode = WebSettings.LOAD_NO_CACHE
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.setSupportMultipleWindows(false)
            settings.javaScriptCanOpenWindowsAutomatically = false
            setBackgroundColor(android.graphics.Color.WHITE)
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val uri = request.url
                    val path = uri.pathSegments
                    if (uri.scheme == "https" && uri.host == "iumrah.app" &&
                        path.size == 2 && path[0] == "s" && path[1].matches(Regex("^[A-Za-z0-9_-]{43}$"))) {
                        return false
                    }
                    // CTA actions (e.g. 'build the same trip') open in the
                    // ordinary browser, not inside the restricted viewer.
                    if (uri.scheme == "https" && uri.host != null) {
                        runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, uri)) }
                    }
                    return true
                }
            }
            loadUrl(if (safeToken != null) "https://iumrah.app/s/$safeToken" else "https://iumrah.app/")
        }
    }
    DisposableEffect(webView) {
        onDispose {
            webView.stopLoading()
            webView.loadUrl("about:blank")
            webView.destroy()
        }
    }
    AndroidView(factory = { webView }, modifier = Modifier.fillMaxSize())
}
