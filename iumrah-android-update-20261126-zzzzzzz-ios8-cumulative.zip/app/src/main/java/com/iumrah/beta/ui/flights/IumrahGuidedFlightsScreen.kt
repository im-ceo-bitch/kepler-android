@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.iumrah.beta.ui.flights

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.IconButton
import androidx.compose.ui.platform.LocalContext
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import com.iumrah.beta.data.flight.FlightDiscoveryCalendarDay
import com.iumrah.beta.data.flight.FlightDataParity
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.iumrah.beta.core.analytics.IumrahIntelligence
import com.iumrah.beta.core.navigation.AppChromeStore
import com.iumrah.beta.core.settings.AppLanguage
import com.iumrah.beta.data.flight.AirportSearchService
import com.iumrah.beta.data.flight.AviasalesFlightDiscoveryService
import com.iumrah.beta.data.flight.CuratedFlightRecommendationService
import com.iumrah.beta.data.flight.FlightDiscoveryOffer
import com.iumrah.beta.domain.journey.JourneyStore
import com.iumrah.beta.domain.nuitee.NuiteeFlightSnapshot
import com.iumrah.beta.domain.trip.FlightTripType
import com.iumrah.beta.domain.trip.JourneyScope
import com.iumrah.beta.domain.trip.PackageFlightPath
import com.iumrah.beta.domain.trip.SaudiArrivalAirport
import com.iumrah.beta.models.flight.CuratedFlightRecommendation
import com.iumrah.beta.models.flight.FlightCabinClass
import com.iumrah.beta.ui.components.IumrahPrimaryButton
import com.iumrah.beta.ui.cupertino.CupertinoSymbol
import com.iumrah.beta.ui.cupertino.Icon
import com.iumrah.beta.ui.trip.ConfiguratorAirportSelector
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch

/**
 * Flight-first search counterpart of the current SwiftUI IumrahGuidedFlightSelectionView.
 * Independent legs may mix only under the existing server quote contract.
 * No guessed fares, fabricated segments, or new API endpoints.
 */
@Composable
fun IumrahGuidedFlightsScreen(
    language: AppLanguage,
    journey: JourneyStore,
    curated: CuratedFlightRecommendationService,
    discovery: AviasalesFlightDiscoveryService,
    airports: AirportSearchService,
    chrome: AppChromeStore,
    lockParty: Boolean = false,
    onBack: () -> Unit = { chrome.back() },
    onComplete: () -> Unit = { chrome.openNuiteeJourneyHotels() },
) {
    val state by journey.state.collectAsState()
    val trip = state.trip
    val scope = rememberCoroutineScope()
    var editing by remember { mutableStateOf(false) }
    var stepReturn by remember { mutableStateOf(false) }
    var outbound by remember { mutableStateOf<GuidedFlightChoice?>(null) }
    var inbound by remember { mutableStateOf<GuidedFlightChoice?>(null) }
    var published by remember { mutableStateOf<List<CuratedFlightRecommendation>>(emptyList()) }
    var dataOutbound by remember { mutableStateOf<List<FlightDiscoveryOffer>>(emptyList()) }
    var dataReturn by remember { mutableStateOf<List<FlightDiscoveryOffer>>(emptyList()) }
    var filters by remember { mutableStateOf(GuidedFilters()) }
    var outboundCalendar by remember { mutableStateOf<List<FlightDiscoveryCalendarDay>>(emptyList()) }
    var returnCalendar by remember { mutableStateOf<List<FlightDiscoveryCalendarDay>>(emptyList()) }
    val calendarCache = remember { mutableMapOf<String, Pair<Long, List<FlightDiscoveryCalendarDay>>>() }
    var busy by remember { mutableStateOf(false) }
    var loadingError by remember { mutableStateOf<String?>(null) }
    var selectionError by remember { mutableStateOf<String?>(null) }
    var pending by remember { mutableStateOf<GuidedFlightChoice?>(null) }
    val listState = rememberLazyListState()
    var detail by remember { mutableStateOf<GuidedFlightChoice?>(null) }
    var dateField by remember { mutableStateOf<Boolean?>(null) } // false departure, true return
    var refreshKey by remember { mutableIntStateOf(0) }
    val searchIdentity = listOf(trip.originCode, trip.outboundDestinationCode, trip.returnOriginCode, trip.departureDate, trip.returnDate,
        trip.effectiveFlightFilters.cabinClass, trip.adults, trip.children, trip.infants)
    var loadedIdentity by remember { mutableStateOf<List<Any>?>(null) }
    // Keep the confirmed outbound when only the return date changes.
    val outboundIdentity = listOf(trip.originCode, trip.outboundDestinationCode, trip.returnOriginCode,
        trip.departureDate, trip.effectiveFlightFilters.cabinClass, trip.adults, trip.children, trip.infants)
    var loadedOutboundIdentity by remember { mutableStateOf<List<Any>?>(null) }

    LaunchedEffect(searchIdentity, refreshKey) {
        val sameSearch = loadedIdentity == searchIdentity
        if (!sameSearch) {
            pending = null; inbound = null
            if (loadedOutboundIdentity != outboundIdentity) {
                outbound = null; stepReturn = false; dataOutbound = emptyList(); outboundCalendar = emptyList()
            }
            published = emptyList(); dataReturn = emptyList(); returnCalendar = emptyList()
        }
        loadedIdentity = searchIdentity
        loadedOutboundIdentity = outboundIdentity
        loadingError = null
        busy = true
        IumrahIntelligence.record("search_started", "flight_builder", "published_and_data")
        var firstError: Throwable? = null
        try {
            val nextPublished = try { curated.load(trip) }
            catch (ex: CancellationException) { throw ex }
            catch (ex: Exception) { firstError = ex; null }
            kotlinx.coroutines.currentCoroutineContext().ensureActive()
            if (nextPublished != null) published = nextPublished
            if (trip.effectiveFlightFilters.cabinClass == FlightCabinClass.ECONOMY) {
                // Retain the same exact-day and surrounding-month fallback as SwiftUI.
                val legs = listOf(
                    Triple(trip.originCode, trip.outboundDestinationCode, trip.departureDate),
                    Triple(trip.returnOriginCode, trip.originCode, trip.returnDate),
                )
                for ((index, leg) in legs.withIndex()) {
                    val (origin, destination, target) = leg
                    val months = (-4..4).map { target.plusDays(it.toLong()).toString().take(7) }.distinct()
                    val rows = mutableListOf<FlightDiscoveryOffer>()
                    var loaded = false
                    for (dayOrMonth in months + target.toString()) {
                        try {
                            val result = discovery.offers(origin, destination, dayOrMonth, direct = false, limit = 100)
                            if (result.currency.equals("USD", true)) { rows += result.offers; loaded = true }
                        } catch (ex: CancellationException) { throw ex
                        } catch (ex: Exception) { if (firstError == null) firstError = ex }
                    }
                    val filtered = rows.filter { it.origin.equals(origin, true) &&
                        it.destination.equals(destination, true) && !it.isRoundTrip }
                        .distinctBy { "${it.id}|${it.departureAt}|${it.flightNumber}" }
                    kotlinx.coroutines.currentCoroutineContext().ensureActive()
                    if (loaded) { if (index == 0) dataOutbound = filtered else dataReturn = filtered }
                    val calendar = mutableListOf<FlightDiscoveryCalendarDay>()
                    val calendarMonths = listOf(target.minusDays(14), target, target.plusDays(14)).map { it.toString().take(7) }.distinct()
                    for (month in calendarMonths) {
                        val key = "$origin|$destination|$month"
                        val now = System.currentTimeMillis()
                        val cached = calendarCache[key]?.takeIf { it.first > now }?.second
                        if (cached != null) calendar += cached else try {
                            val result = discovery.calendar(origin, destination, month)
                            kotlinx.coroutines.currentCoroutineContext().ensureActive()
                            if (result.currency.equals("USD", true)) {
                                calendar += result.days
                                calendarCache.entries.removeAll { it.value.first <= now }
                                calendarCache[key] = (now + 300_000L) to result.days
                            }
                        } catch (ex: CancellationException) { throw ex } catch (_: Exception) { }
                    }
                    if (index == 0) outboundCalendar = calendar else returnCalendar = calendar
                }
            }
            if (published.isEmpty() && dataOutbound.isEmpty() && dataReturn.isEmpty() && firstError != null) {
                loadingError = guidedTr(language,
                    "Не удалось загрузить рейсы. Проверьте подключение и повторите поиск.",
                    "Could not load flights. Check your connection and try again.",
                    "Reyslarni yuklab bo‘lmadi. Internetni tekshirib, qayta urinib ko‘ring.",
                    "Рейсларни юклаб бўлмади. Интернетни текшириб, қайта уриниб кўринг.")
            }
            IumrahIntelligence.record("search_results", "flight_builder",
                if (published.isEmpty() && dataOutbound.isEmpty()) "empty" else "available")
        } finally { busy = false }
    }

    val results = remember(trip, stepReturn, outbound, published, dataOutbound, dataReturn) {
        GuidedFlightRules.options(trip, published, dataOutbound, dataReturn, stepReturn, outbound)
    }
    val target = if (stepReturn) trip.returnDate else trip.departureDate
    val filtered = remember(results, filters) {
        val matching = results.filter { filters.accepts(it.stops, it.airlineCode) }
        val byDate = compareBy<GuidedFlightChoice> { it.departureAt }.thenBy { it.id }
        matching.sortedWith(when(filters.sort) {
            GuidedSort.DATE -> byDate
            GuidedSort.CHEAPEST -> compareBy<GuidedFlightChoice> { it.priceUsd ?: Double.POSITIVE_INFINITY }.then(byDate)
            GuidedSort.FASTEST -> compareBy<GuidedFlightChoice> { it.durationMinutes.takeIf { n -> n > 0 } ?: Int.MAX_VALUE }.then(byDate)
        })
    }
    val groupExact = filtered.filter { GuidedFlightRules.departureDay(it.departureAt, it.origin) == target && it.stops == 0 }
    val groupNearby = filtered.filter { GuidedFlightRules.departureDay(it.departureAt, it.origin) != target }
    val groupConnecting = filtered.filter { GuidedFlightRules.departureDay(it.departureAt, it.origin) == target && it.stops > 0 }
    val minimumDay = if (stepReturn) maxOf(LocalDate.now(), trip.departureDate.plusDays(1)) else LocalDate.now()
    val observations = if (trip.effectiveFlightFilters.cabinClass != FlightCabinClass.ECONOMY) emptyList() else buildList<Pair<LocalDate, Double?>> {
        val origin = if (stepReturn) trip.returnOriginCode else trip.originCode
        val destination = if (stepReturn) trip.originCode else trip.outboundDestinationCode
        (if (stepReturn) dataReturn else dataOutbound).filter { !it.isRoundTrip && it.origin.equals(origin,true) && it.destination.equals(destination,true) && filters.accepts(it.transfers,it.airlineCode) }.forEach { offer ->
            FlightDataParity.localDay(offer.departureAt, offer.origin)?.let { add(it to offer.price) }
        }
        if (filters.airline.isEmpty()) (if (stepReturn) returnCalendar else outboundCalendar).filter { it.returnAt.isNullOrBlank() && it.origin.equals(origin,true) && it.destination.equals(destination,true) && filters.accepts(it.transfers,it.airlineCode) }.forEach { day ->
            runCatching { LocalDate.parse(day.date.take(10)) }.getOrNull()?.let { add(it to day.price) }
        }
    }
    fun selectDay(day: LocalDate) {
        if (day < minimumDay || day == target) return
        pending = null; inbound = null
        if (stepReturn) journey.updateTrip(trip.copy(returnDate = day))
        else { outbound = null; journey.updateTrip(trip.copy(departureDate = day, saudiArrivalDate = null, returnDate = if (trip.returnDate <= day) day.plusDays(7) else trip.returnDate)) }
    }
    val chosen = pending ?: if (stepReturn) inbound else outbound
    LaunchedEffect(stepReturn) { pending = null; filters = GuidedFilters(); listState.scrollToItem(0) }

    fun commit(returnChoice: GuidedFlightChoice? = inbound) {
        if (!GuidedFlightRules.compatible(outbound, returnChoice)) {
            selectionError = guidedTr(language,
                "Выберите совместимые рейсы.", "Choose compatible flights.",
                "Mos reyslarni tanlang.", "Мос рейсларни танланг.")
            return
        }
        val first = requireNotNull(outbound)
        val back = requireNotNull(returnChoice)
        val outDay = requireNotNull(GuidedFlightRules.departureDay(first.departureAt, first.origin))
        val backDay = requireNotNull(GuidedFlightRules.departureDay(back.departureAt, back.origin))
        val arrivalInstant = runCatching { java.time.Instant.parse(first.arrivalAt.orEmpty()) }.getOrNull()
            ?: runCatching { java.time.OffsetDateTime.parse(first.arrivalAt.orEmpty()).toInstant() }.getOrNull()
            ?: runCatching { java.time.OffsetDateTime.parse(first.departureAt).toInstant().plusSeconds(first.durationMinutes.toLong()*60) }.getOrNull()
        val arrivalDay=arrivalInstant?.atZone(java.time.ZoneId.of("Asia/Riyadh"))?.toLocalDate()
        if(arrivalDay==null || java.time.temporal.ChronoUnit.DAYS.between(arrivalDay,backDay)<(if(trip.scope==com.iumrah.beta.domain.trip.JourneyScope.MAKKAH_AND_MADINAH) 2 else 1)) {
            selectionError = guidedTr(language, "Недостаточно ночей для выбранного маршрута.", "Not enough nights for this itinerary.", "Bu yo‘nalish uchun tunlar yetarli emas.", "Бу йўналиш учун тунлар етарли эмас.");return
        }
        val nextTrip = trip.copy(
            departureDate = outDay, saudiArrivalDate=arrivalDay, returnDate = backDay,
            selectedReturnAirport=if(back.origin=="MED") SaudiArrivalAirport.MADINAH else SaudiArrivalAirport.JEDDAH,
            arrivalAirport = if (first.destination == "MED") SaudiArrivalAirport.MADINAH else SaudiArrivalAirport.JEDDAH,
            flightTripType = FlightTripType.ROUND_TRIP,
        )
        when {
            first is GuidedFlightChoice.Published && back is GuidedFlightChoice.Published -> {
                journey.clearStagedAviasalesFlights()
                if (first.publishedPair) {
                    journey.commitTripBuilder(nextTrip, PackageFlightPath.PUBLISHED_DIRECT,
                        completeID = back.recommendation.id)
                } else {
                    journey.commitTripBuilder(nextTrip, PackageFlightPath.PUBLISHED_DIRECT,
                        outboundID = first.recommendation.id, returnID = back.recommendation.id)
                }
            }
            first is GuidedFlightChoice.Data && back is GuidedFlightChoice.Data -> {
                journey.commitTripBuilder(nextTrip,PackageFlightPath.AVIASALES_SELECTED)
                journey.clearStagedAviasalesFlights()
                journey.stageAviasalesFlight(first.offer)
                journey.stageAviasalesFlight(back.offer, returnLeg = true)
                if (!journey.state.value.hasCompleteStagedFlightSelection) {
                    selectionError = guidedTr(language, "Маршрут обратного рейса не совпадает.",
                        "Return flight route is not compatible.", "Qaytish yo‘nalishi mos emas.",
                        "Қайтиш йўналиши мос эмас.")
                    return
                }
            }
            else -> {
                fun identity(choice:GuidedFlightChoice)=when(choice){
                    is GuidedFlightChoice.Published -> "curated:${choice.recommendation.id}"
                    is GuidedFlightChoice.Data -> listOf("aviasales","ow",choice.origin,choice.destination,choice.departureAt.take(10),"-",choice.airlineCode.uppercase(),choice.flightNumber.uppercase().filter{it.isLetterOrDigit()},"-","-").joinToString(":")
                }
                journey.clearStagedAviasalesFlights()
                journey.commitTripBuilder(nextTrip,PackageFlightPath.AVIASALES_SELECTED)
                journey.setMixedFlightIdentity("mixed:${identity(first)}~${identity(back)}")
            }
        }
        journey.startNuiteeJourney(listOf(first, back).map { chosen -> NuiteeFlightSnapshot(
            id = chosen.id, origin = chosen.origin, destination = chosen.destination,
            airline = chosen.airlineName, flightNumber = chosen.flightNumber,
            airlineCode = chosen.airlineCode, durationMinutes = chosen.durationMinutes,
            stops = chosen.stops, departureAt = chosen.departureAt,
            arrivalAt = chosen.arrivalAt, adultFareUSD = chosen.priceUsd.takeUnless { chosen.publishedPair },
        ) })
        IumrahIntelligence.record("tap", "flight_builder", "continue_to_nuitee_hotels")
        onComplete()
    }

    fun confirmChoice(choice: GuidedFlightChoice) {
        if (stepReturn) {
            if (!GuidedFlightRules.compatible(outbound, choice)) {
                selectionError = guidedTr(language, "Выберите совместимые рейсы.", "Choose compatible flights.", "Mos reyslarni tanlang.", "Мос рейсларни танланг.")
                return
            }
            inbound = choice
            IumrahIntelligence.record("flight_selected", "flight_builder", "inbound")
            pending = null
            commit(choice)
        } else {
            if (outbound?.id != choice.id) inbound = null
            outbound = choice
            IumrahIntelligence.record("flight_selected", "flight_builder", "outbound")
            pending = null
            stepReturn = true
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (chosen != null) {
                Box(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.background)
                    .navigationBarsPadding().padding(horizontal = 20.dp, vertical = 9.dp)) {
                    IumrahPrimaryButton(
                        title = if (!stepReturn)
                            guidedTr(language, "Выбрать этот авиабилет", "Choose this flight", "Shu reysni tanlash", "Шу рейсни танлаш")
                        else guidedTr(language, "Выбрать обратный рейс", "Choose this return flight", "Qaytish reysini tanlash", "Қайтиш рейсини танлаш"),
                        onClick = { chosen?.let(::confirmChoice) },
                    )
                }
            }
        },
    ) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding), state = listState, contentPadding = PaddingValues(bottom = 50.dp)) {
            item {
                GuidedFlightHero(language, if (stepReturn) trip.returnOriginCode else trip.originCode, if (stepReturn) trip.originCode else trip.outboundDestinationCode,
                    stepReturn, trip.travelerCount, trip.departureDate, trip.returnDate,
                    editing, onBack, onEdit = { editing = !editing },
                    onRefresh = { refreshKey += 1 })
            }
            item {
                AnimatedVisibility(visible = editing) {
                    Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface)
                        .padding(horizontal = 20.dp, vertical = 15.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(guidedTr(language, "Изменить поиск", "Edit search", "Qidiruvni o‘zgartirish",
                            "Қидирувни ўзгартириш"), fontWeight = FontWeight.Bold)
                        ConfiguratorAirportSelector(language = language, service = airports,
                            airport = trip.originAirport, fallbackCode = trip.originCode,
                            onSelect = { journey.updateTrip(trip.copy(origin = it.iata, originAirport = it)) })
                        if (!lockParty) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(JourneyScope.MAKKAH_ONLY, JourneyScope.MAKKAH_AND_MADINAH).forEach { scopeValue ->
                                val selected = trip.scope == scopeValue
                                Box(Modifier.weight(1f).height(42.dp).clip(RoundedCornerShape(22.dp))
                                    .background(if (selected) Color.Black else MaterialTheme.colorScheme.surfaceVariant)
                                    .clickable { journey.updateTrip(trip.copy(scope = scopeValue,
                                        arrivalAirport = if (scopeValue == JourneyScope.MAKKAH_ONLY)
                                            SaudiArrivalAirport.JEDDAH else trip.arrivalAirport)) },
                                    contentAlignment = Alignment.Center) {
                                    Text(if (scopeValue == JourneyScope.MAKKAH_ONLY)
                                        guidedTr(language, "Мекка", "Makkah", "Makka", "Макка")
                                    else guidedTr(language, "Мекка + Медина", "Makkah + Madinah",
                                        "Makka + Madina", "Макка + Мадина"),
                                        style = MaterialTheme.typography.labelMedium,
                                        color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1)
                                }
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            GuidedEditorButton("${trip.departureDate}", Modifier.weight(1f)) { dateField = false }
                            GuidedEditorButton("${trip.returnDate}", Modifier.weight(1f)) { dateField = true }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(guidedTr(language, "Взрослые", "Adults", "Kattalar", "Катталар"),
                                modifier = Modifier.weight(1f))
                            TextButton(enabled = !lockParty && trip.adults > 1, onClick = {
                                journey.updateTrip(trip.copy(adults = trip.adults - 1,
                                    infants = minOf(trip.infants, trip.adults - 1)))
                            }) { Text("−", fontSize = 22.sp) }
                            Text("${trip.adults}")
                            TextButton(enabled = !lockParty && trip.travelerCount < 9, onClick = {
                                journey.updateTrip(trip.copy(adults = trip.adults + 1))
                            }) { Text("+", fontSize = 22.sp) }
                        }
                        Text(guidedTr(language,
                            "Дети и младенцы сохраняются из параметров поездки на главной.",
                            "Children and infants are preserved from your Home trip settings.",
                            "Bolalar soni asosiy sahifadagi tanlovdan saqlanadi.",
                            "Болалар сони асосий саҳифадаги танловдан сақланади."),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            style = MaterialTheme.typography.labelSmall)
                        TextButton(onClick = { editing = false; refreshKey += 1 }) {
                            Text(guidedTr(language, "Найти рейсы", "Search flights", "Reyslarni qidirish",
                                "Рейсларни қидириш"))
                        }
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 15.dp),
                    horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    GuidedStepChip(
                        guidedTr(language, "Туда", "Outbound", "Borish", "Бориш"),
                        selected = !stepReturn, enabled = true, modifier = Modifier.weight(1f)) { stepReturn = false }
                    GuidedStepChip(
                        guidedTr(language, "Обратно", "Return", "Qaytish", "Қайтиш"),
                        selected = stepReturn, enabled = outbound != null, modifier = Modifier.weight(1f)) { stepReturn = true }
                }
            }
            item {
                Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(if (!stepReturn) guidedTr(language, "Рейсы туда", "Outbound flights", "Borish reyslari", "Бориш рейслари")
                            else guidedTr(language, "Обратные рейсы", "Return flights", "Qaytish reyslari", "Қайтиш рейслари"),
                            style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("${if (stepReturn) trip.returnOriginCode else trip.originCode} → ${if (stepReturn) trip.originCode else trip.outboundDestinationCode} · $target",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (busy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                }
            }
            item {
                GuidedSearchControls(language, filters, { filters = it; pending = null }, results.map { it.airlineCode }.filter { it.isNotBlank() }.distinct().sorted(),
                    observations, target, minimumDay, onCalendar = { dateField = stepReturn }, onSelectDay = ::selectDay)
            }
            if (filtered.isEmpty() && results.isNotEmpty()) item {
                GuidedNotice(guidedTr(language,"Нет рейсов с этими фильтрами.","No flights match these filters.","Filtrlarga mos reyslar yo‘q.","Филтрларга мос рейслар йўқ."), language, onRetry = { filters = GuidedFilters() })
            }
            if (selectionError != null) item {
                GuidedNotice(selectionError.orEmpty(), language, onRetry = { selectionError = null })
            }
            if (loadingError != null && results.isEmpty()) item {
                GuidedNotice(loadingError.orEmpty(), language, onRetry = { refreshKey += 1 })
            }
            if (stepReturn && !busy && results.isEmpty() && outbound != null) item {
                Column(Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
                    Text(guidedTr(language,
                        "Нет совместимых обратных рейсов. Измените рейс туда или даты.",
                        "No compatible return flights. Change outbound flight or dates.",
                        "Mos qaytish reysi yo‘q. Borish reysini yoki sanalarni o‘zgartiring.",
                        "Мос қайтиш рейси йўқ. Бориш рейсини ёки саналарни ўзгартиринг."),
                        style = MaterialTheme.typography.bodyMedium)
                    TextButton(onClick = { inbound = null; outbound = null; stepReturn = false }) {
                        Text(guidedTr(language, "Изменить рейс туда", "Change outbound flight",
                            "Borish reysini o‘zgartirish", "Бориш рейсини ўзгартириш"))
                    }
                }
            } else if (!busy && results.isEmpty() && loadingError == null) item {
                GuidedNotice(guidedTr(language, "Рейсов на эти даты пока нет.",
                    "No flights available for these dates yet.", "Bu sanalarda hozircha reys yo‘q.",
                    "Бу саналарда ҳозирча рейс йўқ."), language, onRetry = { refreshKey += 1 })
            }
            if (groupExact.isNotEmpty()) item { GuidedSectionTitle(guidedTr(language,
                "Прямые на выбранную дату", "Non-stop on your date", "Tanlangan kundagi to‘g‘ri reyslar",
                "Танланган кундаги тўғри рейслар")) }
            items(groupExact, key = { it.id }) { choice ->
                GuidedFlightRow(choice, selected = chosen?.id == choice.id, language = language, onSelect = { pending = if (pending?.id == choice.id) null else choice }, searchDay = target) { detail = choice }
            }
            if (groupConnecting.isNotEmpty()) item { GuidedSectionTitle(guidedTr(language,
                "С пересадкой", "Connecting", "Transferli", "Трансферли")) }
            items(groupConnecting, key = { it.id }) { choice ->
                GuidedFlightRow(choice, selected = chosen?.id == choice.id, language = language, onSelect = { pending = if (pending?.id == choice.id) null else choice }, searchDay = target) { detail = choice }
            }
            if (groupNearby.isNotEmpty()) item { GuidedSectionTitle(guidedTr(language,
                "Ближайшие даты", "Nearby dates", "Yaqin sanalar", "Яқин саналар")) }
            items(groupNearby, key = { it.id }) { choice ->
                GuidedFlightRow(choice, selected = chosen?.id == choice.id, language = language, onSelect = { pending = if (pending?.id == choice.id) null else choice }, searchDay = target) { detail = choice }
            }
            item { Text(guidedTr(language,"Наличие и стоимость проверим после заявки, до оплаты.","Availability and price are checked after your request, before payment.","Mavjudlik va narx arizadan keyin, to‘lovdan oldin tekshiriladi.","Мавжудлик ва нарх аризадан кейин, тўловдан олдин текширилади."), modifier = Modifier.padding(20.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
    }
    detail?.let { item ->
        Dialog(onDismissRequest = { detail = null }, properties=DialogProperties(usePlatformDefaultWidth=false, decorFitsSystemWindows=false)) {
            GuidedFlightDetail(item, language, trip.adults, trip.children, trip.infants, onDismiss={ detail=null }) {
                detail = null
                confirmChoice(item)
            }
        }
    }
    dateField?.let { isReturn ->
        val dateValue = if (isReturn) trip.returnDate else trip.departureDate
        val pickerState = rememberDatePickerState(
            initialSelectedDateMillis = dateValue.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli(),
        )
        DatePickerDialog(
            onDismissRequest = { dateField = null },
            confirmButton = {
                TextButton(onClick = {
                    val picked = pickerState.selectedDateMillis?.let {
                        Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate()
                    }
                    if (picked != null && !picked.isBefore(if (isReturn) maxOf(LocalDate.now(), trip.departureDate.plusDays(1)) else LocalDate.now())) {
                        val next = if (isReturn) {
                            trip.copy(returnDate = maxOf(picked, trip.departureDate.plusDays(1)))
                        } else {
                            trip.copy(departureDate = picked, saudiArrivalDate = null,
                                returnDate = if (trip.returnDate <= picked) picked.plusDays(7) else trip.returnDate)
                        }
                        journey.updateTrip(next)
                    }
                    dateField = null
                }) { Text(guidedTr(language, "Готово", "Done", "Tayyor", "Тайёр")) }
            },
            dismissButton = { TextButton(onClick = { dateField = null }) {
                Text(guidedTr(language, "Отмена", "Cancel", "Bekor", "Бекор"))
            } },
        ) { DatePicker(state = pickerState) }
    }
}

@Composable
private fun GuidedFlightHero(language: AppLanguage, origin: String, destination: String,
    stepReturn: Boolean, count: Int, outboundDay: LocalDate, returnDay: LocalDate,
    editing: Boolean, onBack: () -> Unit, onEdit: () -> Unit, onRefresh: () -> Unit) {
    Column(Modifier.fillMaxWidth().background(Color(0xFF090909))
        .padding(start = 20.dp, end = 20.dp, top = 21.dp, bottom = 25.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).clip(CircleShape).background(Color.White.copy(alpha = .1f))
                .clickable(onClick = onBack), contentAlignment = Alignment.Center) {
                Icon(CupertinoSymbol.ChevronLeft, "Back", Modifier.size(20.dp), Color.White)
            }
            Text(if (stepReturn) guidedTr(language, "Выберите обратный рейс", "Choose return flight", "Qaytish reysini tanlang", "Қайтиш рейсини танланг") else guidedTr(language, "Выберите рейс туда", "Choose outbound flight", "Borish reysini tanlang", "Бориш рейсини танланг"), color = Color.White, style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
            Box(Modifier.size(44.dp).clip(CircleShape).background(Color.White.copy(alpha = .1f))
                .clickable(onClick = onRefresh), contentAlignment = Alignment.Center) {
                Icon(CupertinoSymbol.Refresh, "Refresh flights", Modifier.size(19.dp), Color.White)
            }
        }
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(23.dp))
            .background(Color.White).border(1.dp, Color.White.copy(alpha = .35f), RoundedCornerShape(23.dp))
            .clickable(onClick = onEdit).padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("$origin → $destination",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold, color = Color(0xFF181818), modifier = Modifier.weight(1f))
                Icon(if (editing) CupertinoSymbol.ChevronUp else CupertinoSymbol.ChevronDown,
                    null, Modifier.size(16.dp), Color(0xFF181818))
            }
            Text("$count ${guidedTr(language, "чел.", "travelers", "kishi", "киши")} · $outboundDay – $returnDay",
                style = MaterialTheme.typography.bodySmall, color = Color.DarkGray)
        }
    }
}

@Composable
private fun GuidedEditorButton(title: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(modifier.height(48.dp).clip(RoundedCornerShape(15.dp))
        .background(MaterialTheme.colorScheme.surfaceVariant).clickable(onClick = onClick),
        contentAlignment = Alignment.Center) { Text(title, style = MaterialTheme.typography.bodyMedium) }
}

@Composable
private fun GuidedStepChip(title: String, selected: Boolean, enabled: Boolean,
    modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(modifier.height(58.dp).clip(RoundedCornerShape(28.dp))
        .background(if (selected) Color.Black else MaterialTheme.colorScheme.surface)
        .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 8.dp),
        contentAlignment = Alignment.Center) {
        Text(title, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface.copy(alpha = if (enabled) 1f else .35f),
            fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun GuidedSectionTitle(title: String) {
    Text(title, modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 9.dp),
        fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
}

@Composable
internal fun GuidedFlightRow(choice: GuidedFlightChoice, selected: Boolean,
    language: AppLanguage, onSelect: () -> Unit, searchDay: LocalDate? = null, onClick: () -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    val ink=MaterialTheme.colorScheme.onSurface
    val accent=ink
    val departureDay=FlightDataParity.localDay(choice.departureAt,choice.origin)
    val actualArrival=choice.arrivalAt?.takeIf { FlightDataParity.instant(it)!=null }
    val estimated=actualArrival==null && choice.durationMinutes>0 && FlightDataParity.instant(choice.departureAt)!=null
    val arrival=actualArrival ?: if(estimated) FlightDataParity.instant(choice.departureAt)?.plusSeconds(choice.durationMinutes.toLong()*60)?.toString() else null
    val arrivalDay=arrival?.let { FlightDataParity.localDay(it,choice.destination) }
    Box(Modifier.fillMaxWidth().padding(horizontal=20.dp,vertical=5.dp)) {
        Column(Modifier.fillMaxWidth().heightIn(min=(224*androidx.compose.ui.platform.LocalDensity.current.fontScale.coerceAtLeast(1f)).dp).clip(shape).background(MaterialTheme.colorScheme.surface)
            .border(if(selected)1.5.dp else .75.dp,if(selected)accent else ink.copy(alpha=.07f),shape)
            .clickable(onClick=onClick).padding(14.dp),verticalArrangement=Arrangement.SpaceBetween) {
            Row(Modifier.fillMaxWidth().height(42.dp).padding(end=44.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                val code=choice.airlineCode.uppercase().takeIf { it.matches(Regex("[A-Z0-9]{2}")) }
                Box(Modifier.size(34.dp).clip(RoundedCornerShape(8.dp)).background(Color.White),contentAlignment=Alignment.Center) {
                    if(code!=null) coil3.compose.AsyncImage(model="https://www.gstatic.com/flights/airline_logos/70px/$code.png",contentDescription=null,modifier=Modifier.size(30.dp),contentScale=androidx.compose.ui.layout.ContentScale.Fit)
                    else Icon(CupertinoSymbol.Airplane,null,Modifier.size(20.dp),Color.Black)
                }
                Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(3.dp)) {
                    Text(choice.airlineName,fontSize=16.sp,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis)
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp),verticalAlignment=Alignment.CenterVertically) {
                        if(choice.flightNumber.isNotBlank())Text(choice.flightNumber,fontSize=12.sp,fontWeight=FontWeight.Bold,maxLines=1)
                        Text(if(choice.source==GuidedFlightChoice.Source.PUBLISHED) "iumrah Direct" else guidedTr(language,"Авиабилет","Flight","Aviachipta","Авиачипта"),fontSize=10.sp,color=MaterialTheme.colorScheme.onSurfaceVariant,maxLines=1)
                    }
                }
            }
            Row(verticalAlignment=Alignment.Top,horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                GuidedClock(FlightDataParity.localTime(choice.departureAt,choice.origin),choice.origin,departureDay,false,language,Modifier.weight(1f),Alignment.Start)
                Column(Modifier.width(76.dp).padding(top=2.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(5.dp)) {
                    Text(if(choice.durationMinutes>0) "${choice.durationMinutes/60}h ${choice.durationMinutes%60}m" else "—",modifier=Modifier.height(28.dp),fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant,textAlign=TextAlign.Center)
                    Icon(if(choice.stops==0)CupertinoSymbol.Airplane else CupertinoSymbol.Route,null,Modifier.size(22.dp),ink)
                    Text(if(choice.stops==0)guidedTr(language,"Прямой","Direct","To‘g‘ri","Тўғри") else guidedTr(language,"Пересадок: ${choice.stops}","Stops: ${choice.stops}","Transfer: ${choice.stops}","Трансфер: ${choice.stops}"),fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant,maxLines=1,overflow=TextOverflow.Ellipsis)
                }
                GuidedClock(arrival?.let{FlightDataParity.localTime(it,choice.destination)},choice.destination,arrivalDay,estimated,language,Modifier.weight(1f),Alignment.End)
            }
            HorizontalDivider(color=ink.copy(alpha=.08f))
            Row(Modifier.fillMaxWidth().height(35.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                val price=choice.priceUsd
                if(price!=null)Text(if(choice.publishedPair)guidedTr(language,"Туда и обратно · за пассажира","Round trip · per passenger","Borib qaytish · bir yo‘lovchi","Бориб қайтиш · бир йўловчи") else guidedTr(language,"За пассажира","Per passenger","Bir yo‘lovchi uchun","Бир йўловчи учун"),Modifier.weight(1f),fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
                else Spacer(Modifier.weight(1f))
                Text(price?.let{"$"+"%,.0f".format(Locale.US,it)} ?: guidedTr(language,"Подробнее","Details","Batafsil","Батафсил"),fontSize=if(price==null)15.sp else 25.sp,fontWeight=FontWeight.Bold)
            }
        }
        IconButton(onClick=onSelect,modifier=Modifier.align(Alignment.TopEnd).padding(9.dp).size(44.dp)) {
            Icon(if(selected)CupertinoSymbol.CheckCircleFill else CupertinoSymbol.CircleOutline,guidedTr(language,"Выбрать рейс","Select flight","Reysni tanlash","Рейсни танлаш"),Modifier.size(24.dp),if(selected)accent else MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable private fun GuidedClock(time:String?,airport:String,day:LocalDate?,estimated:Boolean,language:AppLanguage,modifier:Modifier,align:Alignment.Horizontal) {
    Column(modifier,horizontalAlignment=align,verticalArrangement=Arrangement.spacedBy(3.dp)) {
        Text(time?:"—",fontSize=28.sp,fontWeight=FontWeight.Bold,maxLines=1)
        Text(airport.uppercase(),fontSize=19.sp,fontWeight=FontWeight.Bold,maxLines=1)
        Text(day?.format(DateTimeFormatter.ofPattern("d MMM",language.locale))?:"—",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant,maxLines=1)
        if(estimated)Text(guidedTr(language,"Расчётное","Estimated","Hisoblangan","Ҳисобланган"),fontSize=10.sp,color=MaterialTheme.colorScheme.onSurfaceVariant,maxLines=1) else Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun GuidedNotice(text: String, language: AppLanguage, onRetry: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp)
        .clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.surface).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(text, style = MaterialTheme.typography.bodyMedium)
        TextButton(onClick = onRetry) { Text(guidedTr(language, "Повторить", "Retry", "Qayta", "Қайта")) }
    }
}

@Composable
internal fun GuidedFlightDetail(choice: GuidedFlightChoice, language: AppLanguage, adults: Int, children: Int, infants: Int, onDismiss: () -> Unit, onSelect: () -> Unit) {
    val context=LocalContext.current
    Column(Modifier.fillMaxSize().background(if(MaterialTheme.colorScheme.background.red<.5f) Color(0xFF0B0B0B) else Color(0xFFF2F2F2))) {
        Row(Modifier.fillMaxWidth().background(FlightHeroColor).statusBarsPadding().height(48.dp).padding(horizontal=16.dp),verticalAlignment=Alignment.CenterVertically) {
            Icon(CupertinoSymbol.ChevronLeft, guidedTr(language,"Назад","Back","Orqaga","Орқага"),Modifier.size(40.dp).clickable(onClick=onDismiss).padding(8.dp),Color.White)
            Text(choice.airlineName,Modifier.weight(1f),color=Color.White,fontWeight=FontWeight.Bold,fontSize=17.sp,maxLines=1)
            IconButton(onClick={ runCatching { context.startActivity(android.content.Intent.createChooser(android.content.Intent(android.content.Intent.ACTION_SEND).apply { type="text/plain"; putExtra(android.content.Intent.EXTRA_TEXT,"${choice.airlineName} ${choice.flightNumber}\n${choice.origin} → ${choice.destination}\n${choice.departureAt}") },null)) } }) { Icon(CupertinoSymbol.Share,guidedTr(language,"Поделиться","Share","Ulashish","Улашиш"),Modifier.size(20.dp),Color.White) }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).navigationBarsPadding().padding(start=18.dp,end=18.dp,bottom=18.dp),verticalArrangement=Arrangement.spacedBy(14.dp)) {
            FlightDetailLegV46(language, CupertinoSymbol.Airplane, choice.airlineName, choice.origin, choice.destination,
                choice.departureAt, choice.airlineCode, choice.flightNumber, choice.stops, choice.durationMinutes,
                (choice as? GuidedFlightChoice.Data)?.offer?.outboundSegments, choice.arrivalAt, pageHeroInset=18.dp)
        Text(if (choice.source == GuidedFlightChoice.Source.PUBLISHED)
            guidedTr(language, "Опубликованный рейс iumrah · цена подтверждается при расчёте",
                "iumrah published flight · price verified at quote", "iumrah reysi · narx hisobda tekshiriladi",
                "iumrah рейси · нарх ҳисобда текширилади")
        else guidedTr(language, "Наблюдаемая цена авиа-API; доступность проверяется при расчёте",
            "Observed API fare; availability is rechecked at quote",
            "API narxi; mavjudlik hisobda tekshiriladi", "API нархи; мавжудлик ҳисобда текширилади"),
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        choice.priceUsd?.let {
            Text("${"%,.0f".format(Locale.US, it)} $", style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold)
        }
        IumrahPrimaryButton(title = guidedTr(language, "Выбрать этот рейс", "Select this flight",
            "Shu reysni tanlash", "Шу рейсни танлаш"), onClick = onSelect)
        val searchUrl = com.iumrah.beta.data.flight.AviasalesSearchLinkBuilder.searchUrl(choice.origin, choice.destination, choice.departureAt, null, adults, children, infants)
        if (searchUrl != null) androidx.compose.material3.OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = {
            runCatching { context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(searchUrl))) }
        }) { Text(guidedTr(language,"Проверить на Aviasales", "Check on Aviasales", "Aviasales’da tekshirish", "Aviasales’да текшириш")) }
        }
    }
}

private fun guidedTr(language: AppLanguage, ru: String, en: String, uz: String, cy: String) = when (language) {
    AppLanguage.RUSSIAN -> ru
    AppLanguage.UZBEK -> uz
    AppLanguage.UZBEK_CYRILLIC -> cy
    else -> en
}
