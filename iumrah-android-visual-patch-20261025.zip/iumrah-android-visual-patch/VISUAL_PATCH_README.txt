iumrah Android native Compose visual patch — 2026-10-25.
Apply each relative file path to the root of kepler-android-main.

Changes:
  * True Flutter Cupertino glyph font renderer, removing homemade Compose icons.
  * Official CupertinoIcons 1.0.9 font + pinned Flutter icons.dart registry
    downloaded automatically by Gradle on the first connected build.
  * Global Lato typography (also downloaded during first Gradle build).
  * SF SystemName aliases with richer fill/slash variants. No Apple binaries.

Validation: bash scripts/verify-stage25.sh
First native build: Gradle task bootstrapCupertinoIcons (requires Python3, HTTPS)
Caveat: CupertinoIcons package does not contain all modern SF Symbols; see docs.
No iOS repo supplied yet: pixel-to-pixel certification not complete.
