package com.iumrah.beta.core.navigation

fun main() {
    var count = 0
    fun verify(condition: Boolean, name: String) { check(condition) { name }; count++ }
    val chrome = AppChromeStore()
    fun state() = chrome.state.value
    verify(state().currentTab == AppTab.HOME && state().route == AppRoute.Root, "default Home")
    chrome.openDiscoveryFlights()
    verify(state().route == AppRoute.Root && state().currentTab == AppTab.HOTELS && state().discoveryFlights, "Home → root Flights preserves tab bar")
    verify(state().backStack.isEmpty(), "root navigation clears previous stack")
    chrome.openDiscoveryTransfer()
    verify(state().route == AppRoute.TransferService && state().currentTab == AppTab.HOTELS, "transfer preserves originating tab")
    verify(chrome.back() && state().route == AppRoute.Root && state().discoveryFlights, "return to selected Flights board")
    chrome.setDiscoveryFlights(false)
    verify(!state().discoveryFlights && state().currentTab == AppTab.HOTELS, "hotel board selection")
    chrome.openDiscoveryPackage()
    verify(state().route == AppRoute.ManualPackage && state().currentTab == AppTab.HOTELS, "package opens independent manual basket")
    verify(chrome.back() && state().route == AppRoute.Root && !state().discoveryFlights, "return to Hotels board")
    chrome.openDiscoveryBuild()
    verify(state().route == AppRoute.Root && state().currentTab == AppTab.HOME && state().discoveryBuild, "build opens Home search")
    chrome.consumeDiscoveryBuild()
    verify(!state().discoveryBuild, "one shot build request")
    chrome.openDiscoveryBuild()
    chrome.navigate(AppTab.BOOKING)
    verify(!state().discoveryBuild && !state().discoveryFlights && state().currentTab == AppTab.BOOKING, "normal tab clears discovery request")
    chrome.openDiscoveryFlights()
    chrome.navigate(AppTab.HOTELS)
    verify(state().discoveryFlights, "selecting the already active tab retains its current Flights board")
    chrome.startNewTrip()
    verify(state().route == AppRoute.Root && state().currentTab == AppTab.HOME && state().discoveryBuild,
        "current iOS startNewTrip requests existing Home search, not legacy TripBuilder")
    chrome.navigate(AppTab.ACCOUNT)
    chrome.openRewards("friends")
    verify(state().route == AppRoute.Rewards("friends") && state().currentTab == AppTab.ACCOUNT, "Friends route")
    chrome.openRewards("balance")
    verify(state().route == AppRoute.Rewards("balance"), "Balance route")
    verify(chrome.back() && state().route == AppRoute.Rewards("friends"), "Return to Friends")
    verify(chrome.back() && state().route == AppRoute.Root && state().currentTab == AppTab.ACCOUNT, "Return to account")
    chrome.openSavedHotels()
    verify(state().route == AppRoute.SavedHotels && state().currentTab == AppTab.ACCOUNT, "Saved hotels route")
    verify(chrome.back() && state().route == AppRoute.Root && state().currentTab == AppTab.ACCOUNT, "Saved hotels back to account")
    println("V8 discovery navigation: $count checks passed")
}
